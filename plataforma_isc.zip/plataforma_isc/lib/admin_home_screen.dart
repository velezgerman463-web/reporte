import 'package:flutter/material.dart';

class AdminHomeScreen extends StatelessWidget {
  const AdminHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor:
          const Color(0xFF0F2F66),

      body: const Center(
        child: Text(
          "PANTALLA ADMIN",

          style: TextStyle(
            color: Colors.white,
            fontSize: 30,
            fontWeight:
                FontWeight.bold,
          ),
        ),
      ),
    );
  }
}