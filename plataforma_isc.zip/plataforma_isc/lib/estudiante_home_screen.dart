import 'package:flutter/material.dart';

class EstudianteHomeScreen extends StatefulWidget {
  const EstudianteHomeScreen({super.key});

  @override
  State<EstudianteHomeScreen> createState() =>
      _EstudianteHomeScreenState();
}

class _EstudianteHomeScreenState
    extends State<EstudianteHomeScreen> {

  bool mostrarMenu = false;
  bool mostrarEstudiantes = false;
  bool mostrarFormulario = false;

  List<Map<String, String>> estudiantes = [];

  final TextEditingController nombreCtrl =
      TextEditingController();
  final TextEditingController controlCtrl =
      TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [

          // 🔹 CONTENIDO PRINCIPAL
          Container(
            color: const Color(0xFF0F2F66),
            child: SafeArea(
              child: Column(
                children: [

                  const SizedBox(height: 10),

                  Row(
                    children: [

                      const SizedBox(width: 10),

                      GestureDetector(
                        onTap: () {
                          setState(() {
                            mostrarMenu = !mostrarMenu;
                          });
                        },
                        child: Container(
                          width: 40,
                          height: 40,
                          color: Colors.white,
                          child: const Icon(Icons.menu),
                        ),
                      ),

                      const Spacer(),

                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 15, vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius:
                              BorderRadius.circular(15),
                        ),
                        child: const Text(
                          "Instituto Tecnologico de Zacatepec",
                          style: TextStyle(fontSize: 12),
                        ),
                      ),

                      const Spacer(),
                    ],
                  ),

                  const SizedBox(height: 20),

                  const Text(
                    "Mi Proyecto",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 20),

                  Container(
                    width: 250,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white70,
                      borderRadius:
                          BorderRadius.circular(10),
                    ),
                    child: const Text(
                      "Nombre del proyecto",
                      textAlign: TextAlign.center,
                    ),
                  ),

                  const Spacer(),

                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor:
                          const Color(0xFFB4977A),
                    ),
                    onPressed: () {
                      Navigator.pushNamedAndRemoveUntil(
                          context, '/', (route) => false);
                    },
                    child: const Text("salir"),
                  ),

                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),

          // 🔥 MENÚ DESPLEGABLE
          if (mostrarMenu)
            Positioned(
              top: 100,
              left: 20,
              child: Container(
                width: 220,
                padding: const EdgeInsets.all(15),
                decoration: BoxDecoration(
                  color: const Color(0xFFD9D9D9),
                  borderRadius:
                      BorderRadius.circular(15),
                ),
                child: Column(
                  children: [

                    botonMenu("Estudiantes", () {
                      setState(() {
                        mostrarEstudiantes = true;
                        mostrarMenu = false;
                      });
                    }),

                    botonMenu("Resumen del Proyecto", () {}),
                    botonMenu("Calificaciones", () {}),
                    botonMenu("Reconocimiento", () {}),
                    botonMenu("QR y ID_Unico", () {}),
                  ],
                ),
              ),
            ),

          // 🔥 PANEL ESTUDIANTES
          if (mostrarEstudiantes)
            Positioned.fill(
              child: Container(
                color: Colors.black54,
                child: Center(
                  child: Container(
                    width: 500,
                    padding:
                        const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: const Color(0xFFD9D9D9),
                      borderRadius:
                          BorderRadius.circular(15),
                    ),
                    child: Column(
                      mainAxisSize:
                          MainAxisSize.min,
                      children: [

                        const Align(
                          alignment:
                              Alignment.centerLeft,
                          child: Text(
                            "Estudiantes",
                            style: TextStyle(
                                fontWeight:
                                    FontWeight.bold),
                          ),
                        ),

                        const SizedBox(height: 10),

                        Row(
                          mainAxisAlignment:
                              MainAxisAlignment
                                  .spaceBetween,
                          children: const [
                            Text("Alumno"),
                            Text("No.Control"),
                          ],
                        ),

                        const SizedBox(height: 10),

                        ...estudiantes.map((e) => Row(
                              mainAxisAlignment:
                                  MainAxisAlignment
                                      .spaceBetween,
                              children: [
                                Text(e["nombre"]!),
                                Text(e["control"]!),
                              ],
                            )),

                        const SizedBox(height: 20),

                        Row(
                          mainAxisAlignment:
                              MainAxisAlignment
                                  .spaceBetween,
                          children: [

                            ElevatedButton(
                              onPressed: () {
                                setState(() {
                                  mostrarEstudiantes =
                                      false;
                                });
                              },
                              child:
                                  const Text("Cancelar"),
                            ),

                            ElevatedButton(
                              onPressed: () {
                                setState(() {
                                  mostrarFormulario =
                                      true;
                                });
                              },
                              child:
                                  const Text("Add"),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),

          // 🔥 FORMULARIO
          if (mostrarFormulario)
            Positioned.fill(
              child: Container(
                color: Colors.black54,
                child: Center(
                  child: Container(
                    width: 300,
                    padding:
                        const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius:
                          BorderRadius.circular(15),
                    ),
                    child: Column(
                      mainAxisSize:
                          MainAxisSize.min,
                      children: [

                        campoInput(
                            nombreCtrl, "Alumno"),
                        const SizedBox(height: 10),
                        campoInput(
                            controlCtrl,
                            "No Control"),

                        const SizedBox(height: 20),

                        Row(
                          mainAxisAlignment:
                              MainAxisAlignment
                                  .spaceBetween,
                          children: [

                            ElevatedButton(
                              onPressed: () {
                                setState(() {
                                  mostrarFormulario =
                                      false;
                                });
                              },
                              child:
                                  const Text("Cancelar"),
                            ),

                            ElevatedButton(
                              onPressed: () {
                                if (nombreCtrl
                                        .text
                                        .isEmpty ||
                                    controlCtrl
                                        .text
                                        .isEmpty) return;

                                setState(() {
                                  estudiantes.add({
                                    "nombre":
                                        nombreCtrl.text,
                                    "control":
                                        controlCtrl
                                            .text,
                                  });

                                  nombreCtrl.clear();
                                  controlCtrl.clear();

                                  mostrarFormulario =
                                      false;
                                });
                              },
                              child: const Text("OK"),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  // 🔹 BOTÓN MENÚ
  Widget botonMenu(String texto, VoidCallback accion) {
    return Padding(
      padding:
          const EdgeInsets.symmetric(vertical: 5),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor:
              const Color(0xFF0F2F66),
          minimumSize:
              const Size(double.infinity, 40),
        ),
        onPressed: accion,
        child: Text(texto),
      ),
    );
  }

  // 🔹 INPUT
  Widget campoInput(
      TextEditingController controller,
      String hint) {
    return TextField(
      controller: controller,
      decoration: InputDecoration(
        hintText: hint,
        border: OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(10),
        ),
      ),
    );
  }
}