import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class EstudianteHomeScreen extends StatefulWidget {
  const EstudianteHomeScreen({super.key});

  @override
  State<EstudianteHomeScreen> createState() =>
      _EstudianteHomeScreenState();
}

class _EstudianteHomeScreenState
    extends State<EstudianteHomeScreen> {

  bool mostrarMenu = false;
  bool mostrarEstudiantes = false;
  bool mostrarFormulario = false;
  bool mostrarResumen = false;
  bool mostrarQR = false;
  bool mostrarCalificaciones = false;

  final FirebaseFirestore db =
      FirebaseFirestore.instance;

  final FirebaseAuth auth =
      FirebaseAuth.instance;

  final TextEditingController nombreCtrl =
      TextEditingController();

  final TextEditingController controlCtrl =
      TextEditingController();

  String nombreProyecto = "Cargando...";
  String resumenProyecto = "";
  String idUnico = "";

  // 🔥 CALIFICACIONES
  String calificacion =
      "Sin calificación";

  String comentarioCalificacion =
      "";

  @override
  void initState() {
    super.initState();

    cargarProyecto();
  }

  // 🔥 CARGAR PROYECTO
  Future<void> cargarProyecto()
      async {

    try {

      final uid =
          auth.currentUser!.uid;

      final query =
          await db
              .collection("proyectos")
              .where("uid",
                  isEqualTo: uid)
              .get();

      if (query.docs.isNotEmpty) {

        final data =
            query.docs.first.data();

        setState(() {

          nombreProyecto =
              data["nombreProyecto"] ??
                  "Sin proyecto";

          resumenProyecto =
              data["resumen"] ?? "";

          idUnico =
              data["idUnico"] ?? "";

          // 🔥 CALIFICACION
          calificacion =
              data["calificacion"]
                      ?.toString() ??
                  "Sin calificación";

          comentarioCalificacion =
              data["comentario"] ??
                  "";
        });

      } else {

        setState(() {

          nombreProyecto =
              "Sin proyecto";
        });
      }

    } catch (e) {

      setState(() {

        nombreProyecto =
            "Error al cargar";
      });
    }
  }

  // 🔥 GUARDAR ESTUDIANTE
  Future<void> guardarEstudiante()
      async {

    if (nombreCtrl.text.isEmpty ||
        controlCtrl.text.isEmpty) {
      return;
    }

    final uid =
        auth.currentUser!.uid;

    await db.collection(
      "estudiantes",
    ).add({

      "uid": uid,

      "nombre":
          nombreCtrl.text.trim(),

      "control":
          controlCtrl.text.trim(),
    });

    nombreCtrl.clear();
    controlCtrl.clear();

    setState(() {
      mostrarFormulario = false;
    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: Container(
        color: const Color(0xFF0F2F66),

        child: SafeArea(
          child: Stack(
            children: [

              // 🔥 CONTENIDO PRINCIPAL
              Column(
                children: [

                  const SizedBox(height: 10),

                  // 🔹 HEADER
                  Row(
                    children: [

                      const SizedBox(width: 10),

                      // 🔥 MENU
                      GestureDetector(
                        onTap: () {

                          setState(() {
                            mostrarMenu =
                                !mostrarMenu;
                          });
                        },

                        child: Container(
                          width: 40,
                          height: 40,
                          color: Colors.white,

                          child: const Icon(
                            Icons.menu,
                            size: 35,
                          ),
                        ),
                      ),

                      const Spacer(),

                      // 🔥 TITULO
                      Container(
                        padding:
                            const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 8,
                        ),

                        decoration: BoxDecoration(
                          color: Colors.white,

                          borderRadius:
                              BorderRadius.circular(
                                  10),
                        ),

                        child: const Text(
                          "Instituto Tecnologico de Zacatepec",

                          style: TextStyle(
                            fontWeight:
                                FontWeight.bold,
                            fontSize: 12,
                          ),
                        ),
                      ),

                      const Spacer(),
                    ],
                  ),

                  const SizedBox(height: 20),

                  // 🔥 TITULO
                  const Text(
                    "Mi Proyecto",

                    style: TextStyle(
                      color: Colors.white,
                      fontWeight:
                          FontWeight.bold,
                      fontSize: 20,
                    ),
                  ),

                  const SizedBox(height: 20),

                  // 🔥 PROYECTO
                  Container(
                    width: 240,

                    padding:
                        const EdgeInsets.symmetric(
                      vertical: 12,
                      horizontal: 10,
                    ),

                    decoration: BoxDecoration(
                      color:
                          const Color(0xFFD9D9D9),

                      borderRadius:
                          BorderRadius.circular(
                              10),
                    ),

                    child: Text(
                      nombreProyecto,

                      textAlign:
                          TextAlign.center,

                      style: const TextStyle(
                        fontWeight:
                            FontWeight.bold,
                      ),
                    ),
                  ),

                  const SizedBox(height: 30),

                  // 🔥 RESUMEN
                  if (mostrarResumen)
                    Container(
                      width: 320,
                      height: 170,

                      padding:
                          const EdgeInsets.all(
                              15),

                      decoration: BoxDecoration(
                        color:
                            const Color(
                                0xFFD9D9D9),

                        borderRadius:
                            BorderRadius.circular(
                                10),
                      ),

                      child: SingleChildScrollView(
                        child: Text(
                          resumenProyecto,

                          style: const TextStyle(
                            fontSize: 15,
                          ),
                        ),
                      ),
                    ),

                  // 🔥 CALIFICACIONES
                  if (mostrarCalificaciones)
                    Container(
                      width: 320,
                      height: 170,

                      padding:
                          const EdgeInsets.all(
                              15),

                      decoration: BoxDecoration(
                        color:
                            const Color(
                                0xFFD9D9D9),

                        borderRadius:
                            BorderRadius.circular(
                                10),
                      ),

                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,

                        children: [

                          const Text(
                            "Calificación",

                            style: TextStyle(
                              fontWeight:
                                  FontWeight.bold,
                              fontSize: 18,
                            ),
                          ),

                          const SizedBox(
                              height: 15),

                          Text(
                            calificacion,

                            style: const TextStyle(
                              fontSize: 25,
                              fontWeight:
                                  FontWeight.bold,
                            ),
                          ),

                          const SizedBox(
                              height: 15),

                          Text(
                            comentarioCalificacion,

                            style: const TextStyle(
                              fontSize: 15,
                            ),
                          ),
                        ],
                      ),
                    ),

                  // 🔥 QR
                  if (mostrarQR)
                    Column(
                      children: [

                        Container(
                          width: 220,
                          height: 180,

                          decoration:
                              BoxDecoration(
                            color: Colors.white,

                            borderRadius:
                                BorderRadius.circular(
                                    15),
                          ),

                          child: const Center(
                            child: Text(
                              "QR",

                              style: TextStyle(
                                fontSize: 35,
                                fontWeight:
                                    FontWeight.bold,
                              ),
                            ),
                          ),
                        ),

                        const SizedBox(
                            height: 20),

                        Container(
                          padding:
                              const EdgeInsets.all(
                                  12),

                          decoration:
                              BoxDecoration(
                            color: Colors.white,

                            borderRadius:
                                BorderRadius.circular(
                                    10),
                          ),

                          child: Text(
                            idUnico,

                            style:
                                const TextStyle(
                              fontWeight:
                                  FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),

                  const Spacer(),

                  // 🔥 SALIR
                  Align(
                    alignment:
                        Alignment.bottomRight,

                    child: Padding(
                      padding:
                          const EdgeInsets.only(
                        right: 30,
                        bottom: 20,
                      ),

                      child: ElevatedButton(
                        style:
                            ElevatedButton.styleFrom(
                          backgroundColor:
                              const Color(
                                  0xFFB4977A),

                          minimumSize:
                              const Size(
                                  100, 45),
                        ),

                        onPressed: () async {

                          await FirebaseAuth
                              .instance
                              .signOut();

                          if (!mounted) return;

                          Navigator.pushNamedAndRemoveUntil(
                            context,
                            '/',
                            (route) => false,
                          );
                        },

                        child:
                            const Text("salir"),
                      ),
                    ),
                  ),
                ],
              ),

              // 🔥 MENU
              if (mostrarMenu)
                Positioned(
                  top: 90,
                  left: 10,

                  child: Container(
                    width: 220,

                    padding:
                        const EdgeInsets.all(
                            15),

                    decoration: BoxDecoration(
                      color: const Color(
                          0xFFD9D9D9),

                      borderRadius:
                          BorderRadius.circular(
                              15),
                    ),

                    child: Column(
                      children: [

                        botonMenu(
                          "Estudiantes",
                          () {

                            setState(() {

                              mostrarEstudiantes =
                                  true;

                              mostrarResumen =
                                  false;

                              mostrarQR =
                                  false;

                              mostrarCalificaciones =
                                  false;

                              mostrarMenu =
                                  false;
                            });
                          },
                        ),

                        botonMenu(
                          "Resumen del Proyecto",
                          () {

                            setState(() {

                              mostrarResumen =
                                  true;

                              mostrarQR =
                                  false;

                              mostrarCalificaciones =
                                  false;

                              mostrarMenu =
                                  false;
                            });
                          },
                        ),

                        botonMenu(
                          "Calificaciones",
                          () {

                            setState(() {

                              mostrarCalificaciones =
                                  true;

                              mostrarResumen =
                                  false;

                              mostrarQR =
                                  false;

                              mostrarMenu =
                                  false;
                            });
                          },
                        ),

                        botonMenu(
                          "Reconocimiento",
                          () {},
                        ),

                        botonMenu(
                          "QR y ID_Unico",
                          () {

                            setState(() {

                              mostrarQR = true;

                              mostrarResumen =
                                  false;

                              mostrarCalificaciones =
                                  false;

                              mostrarMenu =
                                  false;
                            });
                          },
                        ),
                      ],
                    ),
                  ),
                ),

              // 🔥 PANEL ESTUDIANTES
              if (mostrarEstudiantes)
                Positioned.fill(
                  child: Container(
                    color: Colors.black54,

                    child: Center(
                      child: Container(
                        width: 500,

                        padding:
                            const EdgeInsets.all(
                                20),

                        decoration:
                            BoxDecoration(
                          color: const Color(
                              0xFFD9D9D9),

                          borderRadius:
                              BorderRadius.circular(
                                  15),
                        ),

                        child: Column(
                          mainAxisSize:
                              MainAxisSize.min,

                          children: [

                            const Align(
                              alignment:
                                  Alignment
                                      .centerLeft,

                              child: Text(
                                "Estudiantes",

                                style:
                                    TextStyle(
                                  fontWeight:
                                      FontWeight
                                          .bold,
                                ),
                              ),
                            ),

                            const SizedBox(
                                height: 10),

                            Row(
                              mainAxisAlignment:
                                  MainAxisAlignment
                                      .spaceBetween,

                              children: const [

                                Text("Alumno"),

                                Text(
                                    "No.Control"),
                              ],
                            ),

                            const SizedBox(
                                height: 10),

                            SizedBox(
                              height: 200,

                              child: StreamBuilder(

                                stream: db
                                    .collection(
                                        "estudiantes")
                                    .where(
                                      "uid",
                                      isEqualTo:
                                          auth
                                              .currentUser!
                                              .uid,
                                    )
                                    .snapshots(),

                                builder:
                                    (context,
                                        snapshot) {

                                  if (snapshot
                                          .connectionState ==
                                      ConnectionState
                                          .waiting) {

                                    return const Center(
                                      child:
                                          CircularProgressIndicator(),
                                    );
                                  }

                                  if (!snapshot
                                          .hasData ||
                                      snapshot
                                          .data!
                                          .docs
                                          .isEmpty) {

                                    return const Center(
                                      child: Text(
                                        "No hay estudiantes",
                                      ),
                                    );
                                  }

                                  final docs =
                                      snapshot
                                          .data!
                                          .docs;

                                  return ListView.builder(
                                    itemCount:
                                        docs.length,

                                    itemBuilder:
                                        (context,
                                            index) {

                                      final data =
                                          docs[index]
                                              .data();

                                      return Padding(
                                        padding:
                                            const EdgeInsets.symmetric(
                                          vertical:
                                              5,
                                        ),

                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,

                                          children: [

                                            Text(
                                              data[
                                                      "nombre"] ??
                                                  "",
                                            ),

                                            Text(
                                              data[
                                                      "control"] ??
                                                  "",
                                            ),
                                          ],
                                        ),
                                      );
                                    },
                                  );
                                },
                              ),
                            ),

                            const SizedBox(
                                height: 20),

                            Row(
                              mainAxisAlignment:
                                  MainAxisAlignment
                                      .spaceBetween,

                              children: [

                                ElevatedButton(
                                  onPressed: () {

                                    setState(() {
                                      mostrarEstudiantes =
                                          false;
                                    });
                                  },

                                  child:
                                      const Text(
                                          "Cancelar"),
                                ),

                                ElevatedButton(
                                  onPressed: () {

                                    setState(() {
                                      mostrarFormulario =
                                          true;
                                    });
                                  },

                                  child:
                                      const Text(
                                          "Add"),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),

              // 🔥 FORMULARIO
              if (mostrarFormulario)
                Positioned.fill(
                  child: Container(
                    color: Colors.black54,

                    child: Center(
                      child: Container(
                        width: 300,

                        padding:
                            const EdgeInsets.all(
                                20),

                        decoration:
                            BoxDecoration(
                          color: Colors.white,

                          borderRadius:
                              BorderRadius.circular(
                                  15),
                        ),

                        child: Column(
                          mainAxisSize:
                              MainAxisSize.min,

                          children: [

                            campoInput(
                              nombreCtrl,
                              "Alumno",
                            ),

                            const SizedBox(
                                height: 10),

                            campoInput(
                              controlCtrl,
                              "No Control",
                            ),

                            const SizedBox(
                                height: 20),

                            Row(
                              mainAxisAlignment:
                                  MainAxisAlignment
                                      .spaceBetween,

                              children: [

                                ElevatedButton(
                                  onPressed: () {

                                    setState(() {
                                      mostrarFormulario =
                                          false;
                                    });
                                  },

                                  child:
                                      const Text(
                                          "Cancelar"),
                                ),

                                ElevatedButton(
                                  onPressed:
                                      guardarEstudiante,

                                  child:
                                      const Text(
                                          "OK"),
                                ),
                              ],
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  // 🔥 BOTON MENU
  Widget botonMenu(
    String texto,
    VoidCallback accion,
  ) {

    return Padding(
      padding:
          const EdgeInsets.symmetric(
        vertical: 5,
      ),

      child: ElevatedButton(
        style:
            ElevatedButton.styleFrom(
          backgroundColor:
              const Color(
                  0xFF0F2F66),

          minimumSize:
              const Size(
                  double.infinity,
                  40),
        ),

        onPressed: accion,

        child: Text(texto),
      ),
    );
  }

  // 🔥 INPUT
  Widget campoInput(
    TextEditingController controller,
    String hint,
  ) {

    return TextField(
      controller: controller,

      decoration: InputDecoration(
        hintText: hint,

        border: OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(
                  10),
        ),
      ),
    );
  }
}