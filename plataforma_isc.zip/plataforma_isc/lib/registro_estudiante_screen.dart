import 'package:flutter/material.dart';
import 'qr_screen.dart';
import 'data_holder.dart';

class RegistroEstudianteScreen extends StatefulWidget {
  const RegistroEstudianteScreen({super.key});

  @override
  State<RegistroEstudianteScreen> createState() =>
      _RegistroEstudianteScreenState();
}

class _RegistroEstudianteScreenState
    extends State<RegistroEstudianteScreen> {

  final TextEditingController nombreCtrl =
      TextEditingController();
  final TextEditingController controlCtrl =
      TextEditingController();

  List<Map<String, String>> estudiantes = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F2F66),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            const Text(
              "Registro de Estudiantes",
              style: TextStyle(color: Colors.white),
            ),

            const SizedBox(height: 20),

            campo(nombreCtrl, "Alumno"),
            const SizedBox(height: 10),
            campo(controlCtrl, "No. Control"),

            const SizedBox(height: 10),

            ElevatedButton(
              onPressed: () {
                if (nombreCtrl.text.isEmpty ||
                    controlCtrl.text.isEmpty) return;

                setState(() {
                  estudiantes.add({
                    "nombre": nombreCtrl.text,
                    "control": controlCtrl.text,
                  });

                  nombreCtrl.clear();
                  controlCtrl.clear();
                });
              },
              child: const Text("Agregar"),
            ),

            const SizedBox(height: 20),

            ...estudiantes.map((e) => Text(
                  "${e["nombre"]} - ${e["control"]}",
                  style: const TextStyle(color: Colors.white),
                )),

            const SizedBox(height: 30),

            ElevatedButton(
              onPressed: () {

                // 🔥 GUARDAR TAMBIÉN LOS ESTUDIANTES
                DataHolder.estudiantes = estudiantes;

                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const QrScreen(),
                  ),
                );
              },
              child: const Text("Finalizar"),
            ),
          ],
        ),
      ),
    );
  }

  Widget campo(TextEditingController ctrl, String hint) {
    return Container(
      width: 250,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
      ),
      child: TextField(
        controller: ctrl,
        decoration: InputDecoration(
          hintText: hint,
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 10),
        ),
      ),
    );
  }
}