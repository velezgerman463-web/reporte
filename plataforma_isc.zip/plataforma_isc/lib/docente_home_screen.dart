import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class DocenteHomeScreen extends StatefulWidget {
  const DocenteHomeScreen({super.key});

  @override
  State<DocenteHomeScreen> createState() =>
      _DocenteHomeScreenState();
}

class _DocenteHomeScreenState
    extends State<DocenteHomeScreen> {

  String? categoriaSeleccionada;

  final List<Map<String, dynamic>>
      proyectos = [

    {
      "nombre": "Sistema Web",
      "categoria": "SW",
    },

    {
      "nombre": "Casa Inteligente",
      "categoria": "IOT",
    },

    {
      "nombre": "Robot Autónomo",
      "categoria": "Electronica",
    },
  ];

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor:
          const Color(0xFF0F2F66),

      body: SafeArea(
        child: Padding(
          padding:
              const EdgeInsets.all(20),

          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,

            children: [

              // 🔥 TITULO
              Center(
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),

                  decoration: BoxDecoration(
                    color: Colors.white,

                    borderRadius:
                        BorderRadius.circular(
                            10),
                  ),

                  child: const Text(
                    "Instituto Tecnologico de Zacatepec",

                    style: TextStyle(
                      fontWeight:
                          FontWeight.bold,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 30),

              // 🔥 BIENVENIDA
              Container(
                width: 250,

                padding:
                    const EdgeInsets.symmetric(
                  horizontal: 15,
                  vertical: 10,
                ),

                decoration: BoxDecoration(
                  color:
                      const Color(0xFFD9D9D9),

                  borderRadius:
                      BorderRadius.circular(
                          10),
                ),

                child: const Text(
                  "Bienvenido Profesor:",
                  style: TextStyle(
                    fontWeight:
                        FontWeight.bold,
                  ),
                ),
              ),

              const SizedBox(height: 30),

              Row(
                crossAxisAlignment:
                    CrossAxisAlignment.start,

                children: [

                  // 🔥 TABLA
                  Expanded(
                    child: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment
                              .start,

                      children: [

                        const Padding(
                          padding:
                              EdgeInsets.only(
                                  left: 10),
                          child: Text(
                            "Proyectos",

                            style: TextStyle(
                              color:
                                  Colors.white,

                              fontWeight:
                                  FontWeight
                                      .bold,
                            ),
                          ),
                        ),

                        const SizedBox(
                            height: 10),

                        Container(
                          height: 300,

                          decoration:
                              BoxDecoration(
                            color: Colors.white,

                            borderRadius:
                                BorderRadius.circular(
                                    10),
                          ),

                          child: Column(
                            children: [

                              // 🔥 ENCABEZADOS
                              Container(
                                padding:
                                    const EdgeInsets.all(
                                        10),

                                decoration:
                                    const BoxDecoration(
                                  color: Color(
                                      0xFFD9D9D9),
                                ),

                                child: const Row(
                                  children: [

                                    Expanded(
                                      child: Text(
                                        "Nombre",

                                        style:
                                            TextStyle(
                                          fontWeight:
                                              FontWeight.bold,
                                        ),
                                      ),
                                    ),

                                    Expanded(
                                      child: Text(
                                        "Carrera",

                                        style:
                                            TextStyle(
                                          fontWeight:
                                              FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              // 🔥 LISTA
                              Expanded(
                                child:
                                    ListView.builder(

                                  itemCount:
                                      proyectos.length,

                                  itemBuilder:
                                      (context,
                                          index) {

                                    final proyecto =
                                        proyectos[
                                            index];

                                    return Padding(
                                      padding:
                                          const EdgeInsets.symmetric(
                                        horizontal:
                                            10,
                                        vertical:
                                            8,
                                      ),

                                      child: Row(
                                        children: [

                                          Expanded(
                                            child:
                                                Text(
                                              proyecto[
                                                  "nombre"],
                                            ),
                                          ),

                                          Expanded(
                                            child:
                                                Text(
                                              proyecto[
                                                  "categoria"],
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(width: 20),

                  // 🔥 PANEL DERECHO
                  Column(
                    children: [

                      // 🔥 CATEGORIAS
                      Container(
                        width: 140,

                        padding:
                            const EdgeInsets.symmetric(
                          horizontal: 10,
                        ),

                        decoration:
                            BoxDecoration(
                          color: const Color(
                              0xFFB4977A),

                          borderRadius:
                              BorderRadius.circular(
                                  10),
                        ),

                        child:
                            DropdownButtonHideUnderline(

                          child:
                              DropdownButton<String>(

                            value:
                                categoriaSeleccionada,

                            hint: const Text(
                              "Categorias",

                              style: TextStyle(
                                color:
                                    Colors.white,
                              ),
                            ),

                            dropdownColor:
                                const Color(
                                    0xFFB4977A),

                            iconEnabledColor:
                                Colors.black,

                            items: const [

                              DropdownMenuItem(
                                value: "IOT",

                                child: Text(
                                  "IOT",
                                ),
                              ),

                              DropdownMenuItem(
                                value: "SW",

                                child: Text(
                                  "SW",
                                ),
                              ),

                              DropdownMenuItem(
                                value:
                                    "Electronica",

                                child: Text(
                                  "Electronica",
                                ),
                              ),
                            ],

                            onChanged: (value) {

                              setState(() {
                                categoriaSeleccionada =
                                    value;
                              });
                            },
                          ),
                        ),
                      ),

                      const SizedBox(height: 30),

                      botonDerecha(
                        "Evaluar",
                        () {},
                      ),

                      const SizedBox(height: 20),

                      botonDerecha(
                        "Calificaciones",
                        () {},
                      ),
                    ],
                  ),
                ],
              ),

              const Spacer(),

              // 🔥 SALIR
              Align(
                alignment:
                    Alignment.bottomRight,

                child: ElevatedButton(
                  style:
                      ElevatedButton.styleFrom(
                    backgroundColor:
                        const Color(
                            0xFFB4977A),

                    minimumSize:
                        const Size(
                            120, 45),
                  ),

                  onPressed: () async {

                    await FirebaseAuth
                        .instance
                        .signOut();

                    if (!mounted) return;

                    Navigator.pushNamedAndRemoveUntil(
                      context,
                      '/',
                      (route) => false,
                    );
                  },

                  child:
                      const Text("Salir"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget botonDerecha(
    String texto,
    VoidCallback accion,
  ) {

    return ElevatedButton(
      style:
          ElevatedButton.styleFrom(
        backgroundColor:
            const Color(0xFFB4977A),

        minimumSize:
            const Size(140, 45),
      ),

      onPressed: accion,

      child: Text(texto),
    );
  }
}