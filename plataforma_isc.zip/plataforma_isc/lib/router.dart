import 'package:flutter/material.dart';

import 'login_screen.dart';
import 'registro_proyecto_screen.dart';
import 'estudiante_home_screen.dart';

class AppRouter {

  static Map<String, WidgetBuilder> routes = {

    '/': (context) =>
        const LoginScreen(),

    '/registro': (context) =>
        const RegistroProyectoScreen(),

    '/home': (context) =>
        const EstudianteHomeScreen(),
  };
}