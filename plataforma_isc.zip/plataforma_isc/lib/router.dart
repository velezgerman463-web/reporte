import 'package:go_router/go_router.dart';
import 'package:plataforma_isc/admin_home.dart';
import 'package:plataforma_isc/docente_home.dart';
import 'package:plataforma_isc/docente_proyectos_screen.dart';
import 'estudiante_home_screen.dart';
import 'package:plataforma_isc/register_docente_screen.dart';
import 'package:plataforma_isc/registro_proyecto_screen.dart';
import 'splash_screen.dart';
import 'login_screen.dart';
import 'registro_estudiante_screen.dart';
import 'screens/tipo_registro_screen.dart';
import 'package:plataforma_isc/qr_screen.dart';

final GoRouter appRouter = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(
      path: '/',
      builder: (context, state) => const SplashScreen(),
    ),
    GoRoute(
      path: '/login',
      builder: (context, state) => const LoginScreen(),
    ),
    GoRoute(
      path: '/estudiante',
      builder: (context, state) => const EstudianteHomeScreen(),
    ),
    GoRoute(
      path: '/docente',
      builder: (context, state) => const DocenteHome(),
    ),
    GoRoute(
      path: '/admin',
      builder: (context, state) => const AdminHome(),
    ),
    GoRoute(
      path: '/tipo_registro',
      builder: (context, state) => const TipoRegistroScreen(),
    ),
    GoRoute(
      path: '/registro_proyecto',
      builder: (context, state) => const RegistroProyectoScreen(),
    ),
    GoRoute(
      path: '/registro_estudiante',
      builder: (context, state) => const RegistroEstudianteScreen(),
    ),
    GoRoute(
      path: '/qr',
     builder: (context, state) => const QrScreen(),
    ),
    GoRoute(
      path: '/register_docente',
      builder: (context, state) => const RegisterDocenteScreen(),
    ),
    GoRoute(
      path: '/docente_proyectos',
      builder: (context, state) => const DocenteProyectosScreen(),
),
  ],
);