import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class DocenteProyectosScreen extends StatelessWidget {
  const DocenteProyectosScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D2B5B),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            /// titulo
            Container(
              padding: const EdgeInsets.symmetric(
                  vertical: 20, horizontal: 80),
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Text(
                "Instituto Tecnologico de Zacatepec",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),

            const SizedBox(height: 40),

            /// seccion proyectos
            Container(
              padding: const EdgeInsets.symmetric(
                  vertical: 10, horizontal: 40),
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Text(
                "Proyectos",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),

            const SizedBox(height: 20),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

                /// tabla
                Container(
                  width: 400,
                  height: 250,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                    children: [

                      /// Encabezados
                      Container(
                        padding: const EdgeInsets.all(8),
                        child: const Row(
                          mainAxisAlignment:
                              MainAxisAlignment.spaceAround,
                          children: [
                            Text("Nombre"),
                            Text("Categoria"),
                            Text("Carrera"),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(width: 40),

                /// botones
                Column(
                  children: [
                    buildButton("Evaluar"),
                    const SizedBox(height: 20),
                    buildButton("Categorias"),
                    const SizedBox(height: 20),
                    buildButton("Salir", () {
                      context.go('/');
                    }),
                  ],
                )
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget buildButton(String text, [VoidCallback? onPressed]) {
    return SizedBox(
      width: 130,
      height: 45,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFFB08968),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
        onPressed: onPressed ?? () {},
        child: Text(text),
      ),
    );
  }
}