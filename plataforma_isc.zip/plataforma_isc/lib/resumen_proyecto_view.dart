import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ResumenProyectoView
    extends StatelessWidget {

  const ResumenProyectoView({
    super.key,
  });

  @override
  Widget build(BuildContext context) {

    return StreamBuilder(

      stream: FirebaseFirestore.instance
          .collection("proyectos")
          .snapshots(),

      builder: (context, snapshot) {

        if (snapshot.hasError) {

          return const Text(
            "Error al cargar resumen",
            style:
                TextStyle(color: Colors.white),
          );
        }

        if (snapshot.connectionState ==
            ConnectionState.waiting) {

          return const CircularProgressIndicator();
        }

        if (!snapshot.hasData ||
            snapshot.data!.docs.isEmpty) {

          return const Text(
            "No hay resumen",
            style:
                TextStyle(color: Colors.white),
          );
        }

        final data =
            snapshot.data!.docs.last.data();

        return Container(
          width: 650,
          height: 300,

          padding: const EdgeInsets.all(20),

          decoration: BoxDecoration(
            color:
                const Color(0xFFD9D9D9),

            borderRadius:
                BorderRadius.circular(15),
          ),

          child: SingleChildScrollView(
            child: Text(
              data["resumen"] ?? "",
              style:
                  const TextStyle(fontSize: 16),
            ),
          ),
        );
      },
    );
  }
}