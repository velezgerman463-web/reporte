import 'package:flutter/material.dart';
import 'data_holder.dart';

class ResumenProyectoScreen extends StatelessWidget {
  const ResumenProyectoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F2F66),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            const Text(
              "Resumen del proyecto",
              style: TextStyle(color: Colors.white),
            ),

            const SizedBox(height: 20),

            Container(
              width: 400,
              height: 200,
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(15),
              ),
              child: SingleChildScrollView(
                child: Text(
                  DataHolder.resumen.isEmpty
                      ? "No hay resumen"
                      : DataHolder.resumen,
                ),
              ),
            ),

            const SizedBox(height: 20),

            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Salir"),
            )
          ],
        ),
      ),
    );
  }
}