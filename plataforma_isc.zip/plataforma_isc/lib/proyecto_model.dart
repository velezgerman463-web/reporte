class ProyectoModel {

  final String nombre;
  final String categoria;
  final String docentes;
  final String resumen;
  final String correo;
  final String qrId;

  ProyectoModel({
    required this.nombre,
    required this.categoria,
    required this.docentes,
    required this.resumen,
    required this.correo,
    required this.qrId,
  });

   Map<String, dynamic> toMap() {
    return {
      'nombre': nombre,
      'categoria': categoria,
      'docentes': docentes,
      'resumen': resumen,
      'correo': correo,
      'qrId': qrId,
    };
  }
}