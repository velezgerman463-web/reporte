import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'qr_screen.dart';

class RegistroUsuarioScreen extends StatefulWidget {

  final String nombreProyecto;
  final String categoria;
  final String docentes;
  final String resumen;

  const RegistroUsuarioScreen({
    super.key,
    required this.nombreProyecto,
    required this.categoria,
    required this.docentes,
    required this.resumen,
  });

  @override
  State<RegistroUsuarioScreen> createState() =>
      _RegistroUsuarioScreenState();
}

class _RegistroUsuarioScreenState
    extends State<RegistroUsuarioScreen> {

  final correoCtrl = TextEditingController();

  final passwordCtrl = TextEditingController();

  Future<void> registrarUsuario() async {

    try {

      await FirebaseAuth.instance
          .createUserWithEmailAndPassword(

        email: correoCtrl.text.trim(),
        password: passwordCtrl.text.trim(),
      );

      if (!mounted) return;

      Navigator.pushReplacement(
        context,

        MaterialPageRoute(

          builder: (_) => QrScreen(

            nombreProyecto:
                widget.nombreProyecto,

            categoria:
                widget.categoria,

            docentes:
                widget.docentes,

            resumen:
                widget.resumen,
          ),
        ),
      );

    } on FirebaseAuthException catch (e) {

      String mensaje = "Error";

      if (e.code ==
          'email-already-in-use') {

        mensaje =
            "El correo ya existe";
      }

      if (e.code ==
          'weak-password') {

        mensaje =
            "Contraseña muy débil";
      }

      ScaffoldMessenger.of(context)
          .showSnackBar(

        SnackBar(
          content: Text(mensaje),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor:
          const Color(0xFF0F2F66),

      body: Center(
        child: Column(
          mainAxisAlignment:
              MainAxisAlignment.center,

          children: [

            Container(
              padding:
                  const EdgeInsets.all(10),

              decoration: BoxDecoration(
                color: Colors.white,

                borderRadius:
                    BorderRadius.circular(
                        15),
              ),

              child: const Text(
                "Instituto Tecnologico de Zacatepec",

                style: TextStyle(
                  fontWeight:
                      FontWeight.bold,
                ),
              ),
            ),

            const SizedBox(height: 40),

            campo(
              "Correo",
              correoCtrl,
              false,
            ),

            const SizedBox(height: 20),

            campo(
              "Contraseña",
              passwordCtrl,
              true,
            ),

            const SizedBox(height: 40),

            ElevatedButton(

              style:
                  ElevatedButton.styleFrom(
                backgroundColor:
                    const Color(
                        0xFFB4977A),
              ),

              onPressed:
                  registrarUsuario,

              child:
                  const Text("Aceptar"),
            ),
          ],
        ),
      ),
    );
  }

  Widget campo(
    String texto,
    TextEditingController controller,
    bool ocultar,
  ) {

    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,

      children: [

        Text(
          texto,

          style: const TextStyle(
            color: Colors.white,
          ),
        ),

        const SizedBox(height: 5),

        Container(
          width: 250,
          height: 45,

          decoration: BoxDecoration(
            color: Colors.white,

            borderRadius:
                BorderRadius.circular(
                    10),
          ),

          child: TextField(
            controller: controller,
            obscureText: ocultar,

            decoration:
                const InputDecoration(
              border: InputBorder.none,

              contentPadding:
                  EdgeInsets.symmetric(
                horizontal: 10,
              ),
            ),
          ),
        ),
      ],
    );
  }
}