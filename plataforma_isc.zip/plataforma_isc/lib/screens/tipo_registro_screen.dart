import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class TipoRegistroScreen extends StatelessWidget {
  const TipoRegistroScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D2B5B),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 900),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 40),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

                // Título superior
                Container(
                  padding: const EdgeInsets.symmetric(
                      vertical: 10, horizontal: 30),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Text(
                    "Instituto Tecnologico de Zacatepec",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),

                const SizedBox(height: 40),

                // Pregunta
                Container(
                  padding: const EdgeInsets.symmetric(
                      vertical: 10, horizontal: 30),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade300,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Text(
                    "¿COMO TE QUIERES REGISTRAR?",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),

                const SizedBox(height: 40),

                Row(
                  mainAxisAlignment:
                      MainAxisAlignment.center,
                  children: [

                    _customButton(
                      text: "Estudiantes",
                      onPressed: () => context.go('/registro_proyecto'),
                    ),

                    const SizedBox(width: 40),

                    _customButton(
                      text: "Docentes",
                      onPressed: () => context.go('/register_docente'),
                    ),
                  ],
                ),

                const SizedBox(height: 50),

              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _customButton({
    required String text,
    required VoidCallback onPressed,
  }) {
    return SizedBox(
      width: 180,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor:
              const Color(0xFFB79A7B),
          foregroundColor: Colors.white,
          padding:
              const EdgeInsets.symmetric(vertical: 15),
          shape: RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(12),
          ),
        ),
        onPressed: onPressed,
        child: Text(text),
      ),
    );
  }
}