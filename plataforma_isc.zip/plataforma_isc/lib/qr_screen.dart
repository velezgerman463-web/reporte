import 'dart:math';

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class QrScreen extends StatefulWidget {

  final String nombreProyecto;
  final String categoria;
  final String docentes;
  final String resumen;

  const QrScreen({
    super.key,
    required this.nombreProyecto,
    required this.categoria,
    required this.docentes,
    required this.resumen,
  });

  @override
  State<QrScreen> createState() =>
      _QrScreenState();
}

class _QrScreenState
    extends State<QrScreen> {

  bool cargando = true;

  String idUnico = "";

  @override
  void initState() {
    super.initState();

    guardarProyecto();
  }

  Future<void> guardarProyecto()
      async {

    try {

      final uid =
          FirebaseAuth
              .instance
              .currentUser!
              .uid;

      idUnico =
          "ISC-${Random().nextInt(999999)}";

      await FirebaseFirestore.instance
          .collection("proyectos")
          .add({

        "uid": uid,

        "nombreProyecto":
            widget.nombreProyecto,

        "categoria":
            widget.categoria,

        "docentes":
            widget.docentes,

        "resumen":
            widget.resumen,

        "idUnico":
            idUnico,

        "fecha":
            Timestamp.now(),
      });

      setState(() {
        cargando = false;
      });

    } catch (e) {

      debugPrint(
        "ERROR FIRESTORE: $e",
      );

      ScaffoldMessenger.of(context)
          .showSnackBar(

        SnackBar(
          content: Text(
            e.toString(),
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor:
          const Color(0xFF0F2F66),

      body: Center(
        child: cargando
            ? const CircularProgressIndicator(
                color: Colors.white,
              )
            : Column(
                mainAxisAlignment:
                    MainAxisAlignment.center,

                children: [

                  Container(
                    padding:
                        const EdgeInsets.all(10),

                    decoration: BoxDecoration(
                      color: Colors.white,

                      borderRadius:
                          BorderRadius.circular(
                              15),
                    ),

                    child: const Text(
                      "Instituto Tecnologico de Zacatepec",

                      style: TextStyle(
                        fontWeight:
                            FontWeight.bold,
                      ),
                    ),
                  ),

                  const SizedBox(
                      height: 40),

                  Container(
                    width: 250,
                    height: 180,

                    decoration: BoxDecoration(
                      color: Colors.white,

                      borderRadius:
                          BorderRadius.circular(
                              15),
                    ),

                    child: const Center(
                      child: Icon(
                        Icons.qr_code,
                        size: 120,
                      ),
                    ),
                  ),

                  const SizedBox(
                      height: 20),

                  Container(
                    padding:
                        const EdgeInsets.all(15),

                    decoration: BoxDecoration(
                      color: Colors.white,

                      borderRadius:
                          BorderRadius.circular(
                              10),
                    ),

                    child: Text(
                      idUnico,

                      style: const TextStyle(
                        fontWeight:
                            FontWeight.bold,
                      ),
                    ),
                  ),

                  const SizedBox(
                      height: 30),

                  ElevatedButton(

                    style:
                        ElevatedButton.styleFrom(
                      backgroundColor:
                          const Color(
                              0xFFB4977A),
                    ),

                    onPressed: () {

                      Navigator.pushNamedAndRemoveUntil(
                        context,
                        '/home',
                        (route) => false,
                      );
                    },

                    child:
                        const Text("Salir"),
                  ),
                ],
              ),
      ),
    );
  }
}