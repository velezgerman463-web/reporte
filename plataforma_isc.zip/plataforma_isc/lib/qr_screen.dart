import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'data_holder.dart';
import 'estudiante_home_screen.dart'; // 👈 TU MENÚ

class QrScreen extends StatelessWidget {
  const QrScreen({super.key});

  @override
  Widget build(BuildContext context) {

    final datos = """
Proyecto: ${DataHolder.nombre}
Categoria: ${DataHolder.categoria}
Docentes: ${DataHolder.docentes}
Resumen: ${DataHolder.resumen}
""";

    return Scaffold(
      backgroundColor: const Color(0xFF0F2F66),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            Container(
              padding: const EdgeInsets.all(10),
              color: Colors.white,
              child: QrImageView(
                data: datos,
                size: 200,
              ),
            ),

            const SizedBox(height: 20),

            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFB4977A),
              ),
              onPressed: () {

                // 🔥 REGRESAR AL MENÚ LIMPIANDO TODO
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (_) =>
                        const EstudianteHomeScreen(),
                  ),
                  (route) => false,
                );
              },
              child: const Text("Salir"),
            )
          ],
        ),
      ),
    );
  }
}