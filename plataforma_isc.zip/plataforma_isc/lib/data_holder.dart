class DataHolder {
  static String nombre = "";
  static String categoria = "";
  static String docentes = "";
  static String resumen = "";
  static List<Map<String, String>> estudiantes = [];
}