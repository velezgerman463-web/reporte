import 'package:flutter/material.dart';
import 'registro_estudiante_screen.dart';

class RegistroProyectoScreen extends StatefulWidget {
  const RegistroProyectoScreen({super.key});

  @override
  State<RegistroProyectoScreen> createState() =>
      _RegistroProyectoScreenState();
}

class _RegistroProyectoScreenState
    extends State<RegistroProyectoScreen> {

  final TextEditingController nombreCtrl =
      TextEditingController();

  final TextEditingController docentesCtrl =
      TextEditingController();

  final TextEditingController resumenCtrl =
      TextEditingController();

  String? categoria;

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor:
          const Color(0xFF0F2F66),

      body: Center(
        child: Column(
          mainAxisAlignment:
              MainAxisAlignment.center,

          children: [

            titulo(),

            const SizedBox(height: 40),

            campo(
              "Nombre del Proyecto",
              nombreCtrl,
            ),

            dropdown(),

            campo(
              "Docentes",
              docentesCtrl,
            ),

            campoGrande(
              "Resumen del Proyecto",
              resumenCtrl,
            ),

            const SizedBox(height: 30),

            Row(
              mainAxisAlignment:
                  MainAxisAlignment.center,

              children: [

                boton("Anterior", () {
                  Navigator.pop(context);
                }),

                const SizedBox(width: 20),

                boton("Siguiente", () {

                  Navigator.push(
                    context,

                    MaterialPageRoute(
                      builder: (_) =>
                          RegistroEstudianteScreen(

                        nombreProyecto:
                            nombreCtrl.text,

                        categoria:
                            categoria ?? "",

                        docentes:
                            docentesCtrl.text,

                        resumen:
                            resumenCtrl.text,
                      ),
                    ),
                  );
                }),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget titulo() {
    return Container(
      padding: const EdgeInsets.all(10),

      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(15),
      ),

      child: const Text(
        "Instituto Tecnologico de Zacatepec",

        style: TextStyle(
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget campo(
    String text,
    TextEditingController ctrl,
  ) {

    return fila(
      etiqueta(text),
      input(ctrl),
    );
  }

  Widget campoGrande(
    String text,
    TextEditingController ctrl,
  ) {

    return fila(
      etiqueta(text),
      input(ctrl, alto: 70),
    );
  }

  Widget dropdown() {

    return fila(
      etiqueta("Categoria"),

      Container(
        width: 220,
        height: 60,

        padding:
            const EdgeInsets.symmetric(
          horizontal: 10,
        ),

        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius:
              BorderRadius.circular(10),
        ),

        child: DropdownButton<String>(
          value: categoria,
          isExpanded: true,

          hint: const Text("Selecciona"),

          underline: const SizedBox(),

          items: const [

            DropdownMenuItem(
              value: "IOT",
              child: Text("IOT"),
            ),

            DropdownMenuItem(
              value: "SW",
              child: Text("SW"),
            ),

            DropdownMenuItem(
              value: "Electronica",
              child: Text("Electronica"),
            ),

            DropdownMenuItem(
              value: "Analisis de Datos",
              child: Text(
                  "Analisis de Datos"),
            ),
          ],

          onChanged: (value) {

            setState(() {
              categoria = value;
            });
          },
        ),
      ),
    );
  }

  Widget fila(Widget a, Widget b) {

    return Padding(
      padding:
          const EdgeInsets.symmetric(
        vertical: 10,
      ),

      child: Row(
        mainAxisAlignment:
            MainAxisAlignment.center,

        children: [
          a,
          const SizedBox(width: 20),
          b,
        ],
      ),
    );
  }

  Widget etiqueta(String text) {

    return Container(
      width: 180,

      padding: const EdgeInsets.all(10),

      decoration: BoxDecoration(
        color: const Color(0xFFB4977A),
        borderRadius:
            BorderRadius.circular(10),
      ),

      child: Text(
        text,

        textAlign: TextAlign.center,

        style: const TextStyle(
          color: Colors.white,
        ),
      ),
    );
  }

  Widget input(
    TextEditingController ctrl, {
    double alto = 45,
  }) {

    return Container(
      width: 220,
      height: alto,

      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(10),
      ),

      child: TextField(
        controller: ctrl,

        decoration: const InputDecoration(
          border: InputBorder.none,

          contentPadding:
              EdgeInsets.symmetric(
            horizontal: 10,
          ),
        ),
      ),
    );
  }

  Widget boton(
    String text,
    VoidCallback onPressed,
  ) {

    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor:
            const Color(0xFFB4977A),
      ),

      onPressed: onPressed,

      child: Text(text),
    );
  }
}