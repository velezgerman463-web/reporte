import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'qr_screen.dart';

class RegistroDocenteScreen extends StatefulWidget {
  final String nombreProyecto;
  final String categoria;
  final String docentes;
  final String resumen;

  const RegistroDocenteScreen({
    super.key,
    required this.nombreProyecto,
    required this.categoria,
    required this.docentes,
    required this.resumen,
  });

  @override
  State<RegistroDocenteScreen> createState() =>
      _RegistroDocenteScreenState();
}

class _RegistroDocenteScreenState
    extends State<RegistroDocenteScreen> {

  final TextEditingController correoCtrl =
      TextEditingController();

  final TextEditingController passCtrl =
      TextEditingController();

  bool cargando = false;

  Future<void> registrar() async {

    if (correoCtrl.text.isEmpty ||
        passCtrl.text.isEmpty) {

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            "Completa todos los campos",
          ),
        ),
      );

      return;
    }

    try {

      setState(() {
        cargando = true;
      });

      // 🔥 CREAR USUARIO
      UserCredential userCredential =
          await FirebaseAuth.instance
              .createUserWithEmailAndPassword(

        email: correoCtrl.text.trim(),
        password: passCtrl.text.trim(),
      );

      // 🔥 GUARDAR PROYECTO
      await FirebaseFirestore.instance
          .collection("proyectos")
          .add({

        "uid":
            userCredential.user!.uid,

        "correo":
            correoCtrl.text.trim(),

        "nombreProyecto":
            widget.nombreProyecto,

        "categoria":
            widget.categoria,

        "docentes":
            widget.docentes,

        "resumen":
            widget.resumen,

        "fecha":
            DateTime.now(),
      });

      if (!mounted) return;

      // 🔥 IR AL QR
    Navigator.pushReplacement(
  context,
  MaterialPageRoute(
    builder: (_) => QrScreen(

      nombreProyecto:
          widget.nombreProyecto,

      categoria:
          widget.categoria,

      docentes:
          widget.docentes,

      resumen:
          widget.resumen,
    ),
  ),
);

    } on FirebaseAuthException catch (e) {

      String mensaje =
          "Error al registrar";

      if (e.code ==
          'email-already-in-use') {

        mensaje =
            "Ese correo ya existe";
      }

      if (e.code ==
          'weak-password') {

        mensaje =
            "Contraseña muy débil";
      }

      ScaffoldMessenger.of(context)
          .showSnackBar(

        SnackBar(
          content: Text(mensaje),
        ),
      );

    } catch (e) {

      ScaffoldMessenger.of(context)
          .showSnackBar(

        SnackBar(
          content: Text(
            e.toString(),
          ),
        ),
      );
    }

    if (!mounted) return;

    setState(() {
      cargando = false;
    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor:
          const Color(0xFF0F2F66),

      body: Center(
        child: Column(
          mainAxisAlignment:
              MainAxisAlignment.center,

          children: [

            titulo(),

            const SizedBox(height: 40),

            campo(
              correoCtrl,
              "Correo",
            ),

            const SizedBox(height: 20),

            campo(
              passCtrl,
              "Contraseña",
              pass: true,
            ),

            const SizedBox(height: 30),

            ElevatedButton(
              style:
                  ElevatedButton.styleFrom(
                backgroundColor:
                    const Color(
                        0xFFB4977A),
              ),

              onPressed:
                  cargando
                      ? null
                      : registrar,

              child: cargando
                  ? const CircularProgressIndicator(
                      color: Colors.white,
                    )
                  : const Text("Aceptar"),
            ),
          ],
        ),
      ),
    );
  }

  Widget titulo() {

    return Container(
      padding:
          const EdgeInsets.all(10),

      decoration: BoxDecoration(
        color: Colors.white,

        borderRadius:
            BorderRadius.circular(15),
      ),

      child: const Text(
        "Instituto Tecnologico de Zacatepec",

        style: TextStyle(
          fontWeight:
              FontWeight.bold,
        ),
      ),
    );
  }

  Widget campo(
    TextEditingController ctrl,
    String hint, {
    bool pass = false,
  }) {

    return Container(
      width: 250,

      decoration: BoxDecoration(
        color: Colors.white,

        borderRadius:
            BorderRadius.circular(10),
      ),

      child: TextField(
        controller: ctrl,
        obscureText: pass,

        decoration: InputDecoration(
          hintText: hint,

          border:
              InputBorder.none,

          contentPadding:
              const EdgeInsets.symmetric(
            horizontal: 10,
          ),
        ),
      ),
    );
  }
}