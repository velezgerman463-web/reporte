import 'package:flutter/material.dart';


class RegisterDocenteScreen extends StatelessWidget {
  const RegisterDocenteScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F2F66),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            titulo(),

            const SizedBox(height: 40),

            campo("Correo"),
            campo("Contraseña", pass: true),

            const SizedBox(height: 30),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

                boton("Anterior", () {
                  Navigator.pop(context);
                }),

                const SizedBox(width: 20),

                boton("Aceptar", () {}),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget titulo() {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
      ),
      child: const Text(
        "Instituto Tecnologico de Zacatepec",
      ),
    );
  }

  Widget campo(String text, {bool pass = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [

          Container(
            width: 140,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFFB4977A),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(text,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white)),
          ),

          const SizedBox(width: 20),

          Container(
            width: 220,
            height: 45,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
            ),
            child: TextField(
              obscureText: pass,
              decoration: const InputDecoration(
                border: InputBorder.none,
                contentPadding:
                    EdgeInsets.symmetric(horizontal: 10),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget boton(String text, VoidCallback onPressed) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color(0xFFB4977A),
      ),
      onPressed: onPressed,
      child: Text(text),
    );
  }
}