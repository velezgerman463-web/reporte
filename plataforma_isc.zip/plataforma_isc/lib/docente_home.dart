import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class DocenteHome extends StatelessWidget {
  const DocenteHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Home Estudiante"),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            context.go('/login');
          },
          child: const Text("Cerrar sesión"),
        ),
      ),
    );
  }
}