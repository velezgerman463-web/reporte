import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {

  final FirebaseFirestore _db =
      FirebaseFirestore.instance;

  Future<void> guardarProyecto(
    Map<String, dynamic> data,
  ) async {

    await _db
        .collection('proyectos')
        .add(data);
  }
}