import 'package:flutter/material.dart';
import 'registro_proyecto_screen.dart';
import 'estudiante_home_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
 State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  final TextEditingController correoController = TextEditingController();
  final TextEditingController passController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [

          Expanded(
            child: ClipPath(
              clipper: DiagonalClipper(),
              child: Image.asset(
                "assets/logo.png",
                fit: BoxFit.cover,
              ),
            ),
          ),

          Expanded(
            child: Container(
              color: const Color(0xFF0F2F66),
              padding: const EdgeInsets.symmetric(horizontal: 60),
              child: Column(
                children: [

                  const SizedBox(height: 40),

                  Align(
                    alignment: Alignment.topRight,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFB4977A),
                      ),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) =>
                                const RegistroProyectoScreen(),
                          ),
                        );
                      },
                      child: const Text("Registrarse"),
                    ),
                  ),

                  const Spacer(),

                  const Icon(Icons.auto_awesome,
                      color: Colors.white, size: 30),

                  const SizedBox(height: 20),

                  const Text(
                    "PLATAFORMA INTEGRAL\nPARA EVALUACION DE\nPROYECTOS FINALES\nDEL ISC-ITZ",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold),
                  ),

                  const SizedBox(height: 40),

                  campo("Correo Electrónico", false, correoController),
                  const SizedBox(height: 20),
                  campo("Contraseña", true, passController),

                  const SizedBox(height: 40),

                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFB4977A),
                    ),
                    onPressed: () {

                      String correo = correoController.text.trim();
                      String pass = passController.text.trim();

                      if (correo.isEmpty || pass.isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                              content: Text("Completa todos los campos")),
                        );
                        return;
                      }

                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) =>
                              const EstudianteHomeScreen(),
                        ),
                      );
                    },
                    child: const Text("Iniciar Sesion"),
                  ),

                  const Spacer(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget campo(String label, bool pass, TextEditingController controller) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: const TextStyle(color: Colors.white)),
        const SizedBox(height: 5),
        Container(
          height: 45,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
          ),
          child: TextField(
            controller: controller,
            obscureText: pass,
            decoration: const InputDecoration(
              border: InputBorder.none,
              contentPadding:
                  EdgeInsets.symmetric(horizontal: 10),
            ),
          ),
        ),
      ],
    );
  }
}

class DiagonalClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = Path();
    path.lineTo(size.width * 0.75, 0);
    path.lineTo(size.width * 0.95, size.height);
    path.lineTo(0, size.height);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) =>
      false;
}