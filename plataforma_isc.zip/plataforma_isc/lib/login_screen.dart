import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'registro_proyecto_screen.dart';
import 'docente_home_screen.dart';
import 'admin_home_screen.dart';
import 'estudiante_home_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() =>
      _LoginScreenState();
}

class _LoginScreenState
    extends State<LoginScreen> {

  final correoCtrl =
      TextEditingController();

  final passCtrl =
      TextEditingController();

  bool cargando = false;

  // 🔥 LOGIN INTELIGENTE
  Future<void> iniciarSesion()
      async {

    try {

      setState(() {
        cargando = true;
      });

      await FirebaseAuth.instance
          .signInWithEmailAndPassword(

        email:
            correoCtrl.text.trim(),

        password:
            passCtrl.text.trim(),
      );

      final query =
          await FirebaseFirestore
              .instance
              .collection("usuarios")
              .where(
                "correo",
                isEqualTo:
                    correoCtrl.text.trim(),
              )
              .get();

      if (query.docs.isNotEmpty) {

        final data =
            query.docs.first.data();

        final rol =
            data["rol"];

        // 🔥 DOCENTE
        if (rol == "docente") {

          if (!mounted) return;

          Navigator.pushReplacement(
            context,

            MaterialPageRoute(
              builder: (_) =>
                  const DocenteHomeScreen(),
            ),
          );

          return;
        }

        // 🔥 ADMIN
        if (rol == "admin") {

          if (!mounted) return;

          Navigator.pushReplacement(
            context,

            MaterialPageRoute(
              builder: (_) =>
                  const AdminHomeScreen(),
            ),
          );

          return;
        }
      }

      // 🔥 ESTUDIANTE
      if (!mounted) return;

      Navigator.pushReplacement(
        context,

        MaterialPageRoute(
          builder: (_) =>
              const EstudianteHomeScreen(),
        ),
      );

    } on FirebaseAuthException catch (e) {

      String mensaje =
          "Error al iniciar sesión";

      if (e.code ==
          'user-not-found') {

        mensaje =
            "Usuario no encontrado";
      }

      if (e.code ==
          'wrong-password') {

        mensaje =
            "Contraseña incorrecta";
      }

      ScaffoldMessenger.of(context)
          .showSnackBar(

        SnackBar(
          content: Text(mensaje),
        ),
      );

    } catch (e) {

      ScaffoldMessenger.of(context)
          .showSnackBar(

        SnackBar(
          content: Text(
            e.toString(),
          ),
        ),
      );
    }

    setState(() {
      cargando = false;
    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor:
          const Color(0xFF0F2F66),

      body: Center(
        child: Row(
          mainAxisAlignment:
              MainAxisAlignment.center,

          children: [

            // 🔥 LOGO IZQUIERDA
            Container(
              width: 220,
              height: 220,

              decoration: BoxDecoration(
                color: Colors.white,

                borderRadius:
                    BorderRadius.circular(
                        20),
              ),

              child: const Icon(
                Icons.school,
                size: 120,
                color: Color(0xFF0F2F66),
              ),
            ),

            const SizedBox(width: 80),

            // 🔥 LOGIN
            Column(
              mainAxisAlignment:
                  MainAxisAlignment.center,

              crossAxisAlignment:
                  CrossAxisAlignment.start,

              children: [

                Container(
                  padding:
                      const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),

                  decoration: BoxDecoration(
                    color: Colors.white,

                    borderRadius:
                        BorderRadius.circular(
                            10),
                  ),

                  child: const Text(
                    "Instituto Tecnologico de Zacatepec",

                    style: TextStyle(
                      fontWeight:
                          FontWeight.bold,
                    ),
                  ),
                ),

                const SizedBox(height: 40),

                const Text(
                  "Correo",

                  style: TextStyle(
                    color: Colors.white,
                    fontWeight:
                        FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 5),

                campo(
                  correoCtrl,
                  false,
                ),

                const SizedBox(height: 20),

                const Text(
                  "Contraseña",

                  style: TextStyle(
                    color: Colors.white,
                    fontWeight:
                        FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 5),

                campo(
                  passCtrl,
                  true,
                ),

                const SizedBox(height: 30),

                Center(
                  child: ElevatedButton(
                    style:
                        ElevatedButton.styleFrom(
                      backgroundColor:
                          const Color(
                              0xFFB4977A),

                      minimumSize:
                          const Size(
                              180, 45),
                    ),

                    onPressed:
                        cargando
                            ? null
                            : iniciarSesion,

                    child: cargando
                        ? const CircularProgressIndicator(
                            color:
                                Colors.white,
                          )
                        : const Text(
                            "Iniciar Sesión",
                          ),
                  ),
                ),

                const SizedBox(height: 20),

                Center(
                  child: TextButton(
                    onPressed: () {

                      Navigator.push(
                        context,

                        MaterialPageRoute(
                          builder: (_) =>
                              const RegistroProyectoScreen(),
                        ),
                      );
                    },

                    child: const Text(
                      "Registrar Proyecto",

                      style: TextStyle(
                        color: Colors.white,
                        fontWeight:
                            FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget campo(
    TextEditingController controller,
    bool ocultar,
  ) {

    return Container(
      width: 280,
      height: 45,

      decoration: BoxDecoration(
        color: Colors.white,

        borderRadius:
            BorderRadius.circular(10),
      ),

      child: TextField(
        controller: controller,
        obscureText: ocultar,

        decoration:
            const InputDecoration(
          border: InputBorder.none,

          contentPadding:
              EdgeInsets.symmetric(
            horizontal: 10,
          ),
        ),
      ),
    );
  }
}