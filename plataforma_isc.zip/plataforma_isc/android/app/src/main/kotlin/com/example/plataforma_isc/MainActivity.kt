package com.example.plataforma_isc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
